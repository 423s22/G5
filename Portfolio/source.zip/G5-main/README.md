# G5
## Shopify App

Members: John, Ryan, Nathan

[Shopify Embedded Storefront App Demo](https://esof-423-develop.myshopify.com/ )
password: "admin"
Go to catalog->product to view embedded storefront app.

[Shopify Merchant App Demo](https://esof-423-develop.myshopify.com/admin/apps/app3-38)
Must be added as staff member to view.

[Burndown Chart and Backlog](https://docs.google.com/spreadsheets/d/1fbTvqHgkvX9-SGKE4A3aeYmjwZX76ZWmz2ZxYkLH1UU/edit?usp=sharing)

[Documentation](https://docs.google.com/document/d/1XqmqsgYq1fYXmSpOW8mcKBggAJceFS2Ye1M_P6J0Zyo/edit?usp=sharing)

[Portfolio](https://docs.google.com/document/d/1oS874Ev1zOlgG9_86bpZUQma0Xcyu25tLzf77Pnuwkk/edit?usp=sharing)

[User Evaluation](https://docs.google.com/document/d/10TF7tXr__18VF69fEQOOmf4M6hktVO3D6a_LQTJNuwc/edit?usp=sharing)

Member handles:
Nathan (user-nate);
John (johnjubes);
Ryan (ryankrauss)
